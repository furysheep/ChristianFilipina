/**
 * This file contains metric values that are global to the application.
 */

export default {
  baseMargin: 10,
  largeMargin: 20,
  smallMargin: 5,
}
